const CACHE='lead-english-correct-v1';
const CORE=[
'./','./index.html','./manifest.json','./icon.svg',
'./grade1_source.html','./grade2_source.html','./grade3_source.html',
'./Grade4_Jordan_TeamTogether_S1_Daily_Planner.html',
'./Grade4_Jordan_TeamTogether_S2_5E_Siraj_Lesson_Planner-3.html',
'./grade5_source.html','./grade6_source.html'
];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x))))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
